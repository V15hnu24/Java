package sample;

public interface constants {
    public static final int width = 640;
    public static final int height = 600;

}
