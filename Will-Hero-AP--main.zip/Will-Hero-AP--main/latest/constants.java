package sample;

public interface constants {
    public static final int width = 700;
    public static final int height = 600;

}
